<?php
require '../koneksi.php';

function query($query){
    
    global $conn;
    $row = [];
    $result = mysqli_query($conn, $query);
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}


function tambahUser($data){
    global $conn;
    
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
    $role = htmlspecialchars($data["role"]);

    $query = "INSERT INTO user VALUES(NULL, '$username', '$password', '$role')";

    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}


function hapusUser($id){
    global $conn;

    mysqli_query($conn, "DELETE FROM user WHERE id_user = '$id'");
    return mysqli_affected_rows($conn);
}

function editUser($data){
    global $conn;

    $id = htmlspecialchars($data["id_user"]);    
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
    $role = htmlspecialchars($data["role"]);

    $query = "UPDATE user SET 
    username = '$username',
    password = '$password',
    role = '$role' WHERE id_user = '$id'
    ";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

}

function tambahProduk($data){
    global $conn;

    $nama_produk = htmlspecialchars($data["nama_produk"]);
    $merk_produk = htmlspecialchars($data["merk_produk"]);
    $harga = htmlspecialchars($data["harga"]);

    $query = "INSERT INTO produk VALUES(NULL, '$nama_produk', '$merk_produk', '$harga')";

    
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);

}

function hapusProduk($id){
    global $conn;

    mysqli_query($conn, "DELETE FROM produk WHERE id_produk = '$id'");
    return mysqli_affected_rows($conn);
}


function editProduk($data){
    global $conn;

    $id = htmlspecialchars($data["id_produk"]);    
    $nama_produk = htmlspecialchars($data["nama_produk"]);
    $merk_produk = htmlspecialchars($data["merk_produk"]);
    $harga = htmlspecialchars($data["harga"]);

    if(empty($data)){
        $query = "UPDATE produk SET
        nama_produk = '$nama_produk',
        merk_produk = '$merk_produk',
        harga = '$harga', WHERE id_produk = '$id'";

        mysqli_query($conn, $query);
        return mysqli_affected_rows($conn);
    }else{
        $query = "UPDATE produk SET
        nama_produk = '$nama_produk',
        merk_produk = '$merk_produk',
        harga = '$harga' WHERE id_produk = '$id'";
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }
}

function editTransaksi($data){
    global $conn;

    $jumlah_produk = htmlspecialchars($data["jumlah_produk"]);    
    $tgl_transaksi = htmlspecialchars($data["tgl_transaksi"]);
    $id_produk = htmlspecialchars($data["id_produk"]);
    $id_user = htmlspecialchars($data["id_user"]);

    if(empty($data)){
        $query = "UPDATE transaksi SET
        jumlah_produk = '$jumlah_produk',
        tgl_transaksi = '$tgl_transaksi',
        id_produk = '$id_produk',
        id_user = '$id_user', WHERE id_produk = '$id_produk'";

        mysqli_query($conn, $query);
        return mysqli_affected_rows($conn);
    }else{
        $query = "UPDATE transaksi SET
        jumlah_produk = '$jumlah_produk',
        tgl_transaksi = '$tgl_transaksi',
        id_produk = '$id_produk',
        id_user = '$id_user' WHERE id_produk = '$id_produk'";
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }
}

function hapusTransaksi($id){
    global $conn;

    mysqli_query($conn, "DELETE FROM transaksi WHERE id_produk = '$id'");
    return mysqli_affected_rows($conn);
}

function tambahTransaksi($data){
    global $conn;

    $jumlah_produk = htmlspecialchars($data["jumlah_produk"]);
    $tgl_transaksi = htmlspecialchars($data["tgl_transaksi"]);
    $id_produk = htmlspecialchars($data["id_produk"]);
    $id_user = htmlspecialchars($data["id_user"]);

    $query = "INSERT INTO transaksi VALUES(NULL, '$jumlah_produk', '$tgl_transaksi', '$id_produk', '$id_user')";


    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}



?>