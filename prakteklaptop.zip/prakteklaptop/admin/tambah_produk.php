<?php 
session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

if(isset($_POST["kirim"])){
    if(tambahProduk($_POST) > 0){
        echo "
        <script type='text/javascript'>
            alert('Data Produk Berhasil Ditambahkan')
            window.location = 'produk.php';
        </script>
        ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Data Produk Gagal Ditambahkan')
            window.location = 'produk.php';
    </script>
        ";
    }
}

?>

<?php require '../layout/sidebar.php'?>

<div class="main">
    <div class="box">
        <h3>Tambah Data produk</h3>

        <form action="" method="POST" enctype="multipart/form-data">

        <label for="nama_produk">Nama Produk</label>
            <input type="text" name="nama_produk" id="nama_produk" class="form-control">

            <label for="merk_produk">merk_produk</label>
            <input type="text" name="merk_produk" id="merk_produk" class="form-control">


            <label for="harga">harga</label>
            <input type="text" name="harga" id="harga" class="form-control">
            </select>
            <button tytpe="submit" name="kirim">Tambah</button>
        </form>
    </div>
</div>