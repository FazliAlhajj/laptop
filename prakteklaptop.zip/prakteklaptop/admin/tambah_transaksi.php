<?php

session_start();
require 'functions.php';

if(isset($_POST["kirim"])){
    if(tambahTransaksi($_POST) > 0){
        echo"
            <script type='text/javascript'>
                alert('Data produk berhasil ditambahkan');
                window.location = 'transaksi.php'
            </script>
        ";
    }else{
        echo"
        <script type='text/javascript'>
            alert('Data produk gagal ditambahkan');
            window.location = 'transaksi.php'
        </script>
    ";
    }
}

require '../layout/sidebar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
</head>
<body>
<div class="main">
    <div class="box">

        <h3>Tambah Data Transaksi</h3>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="jumlah_produk">Jumlah Produk</label>
            <input type="text" name="jumlah_produk" id="jumlah_produk" class="form-control">

            <label for="tgl_transaksi">Tanggal Transaksi</label>
            <input type="date" name="tgl_transaksi" id="tgl_transaksi" class="form-control">

            <label for="id_produk">Id Produk</label>
            <input type="text" name="id_produk" id="id_produk" class="form-control">
            
            <label for="id_user">Id User</label>
            <input type="text" name="id_user" id="id_user" class="form-control">

            <button type="submit" name="kirim">Tambah</button>
        </form>
    </div>
</div>
</body>
</html>