<?php

require 'functions.php';

$id = $_POST["id_produk"];
$nama_produk = $_POST["nama_produk"];
$merk_produk = $_POST["merk_produk"];
$harga = $_POST["harga"];

$query = mysqli_query($conn, "UPDATE produk SET 
nama_produk = '$nama_produk',
merk_produk = '$merk_produk',
harga = '$harga' WHERE id_produk = '$id' ");

if($query){
    echo'
        <script type="text/javascript">
            alert("data berhasil diubah!");
            window.location = "index.php";
        </script>  
    ';
}

?>