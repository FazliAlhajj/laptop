<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktek SMK Jakarta Pusat 1 </title>
    <link rel="stylesheet" href="../css/admin.css">
    <link href="https://fonts.googleapis.com/css?family=Assistant:200,300,400,600,700,800|Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
</head>
<body>  
    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="user.php">Data User</a>
        <a href="produk.php">Data Produk</a>
        <a href="transaksi.php">Data Transaksi</a>
        <a href="../logout.php">Logout</a>
    </div>
</body>
</html>